const auth=(server)=>{
    /*server.extend('post', 'send-email-verification', (req, res) => {
        res.send('');
    });
    server.extend('post', 'verify-email-code', (req, res) => {
        res.send('');
    });
    server.extend('post', 'send-forgot-password', (req, res) => {
        res.send('');
    });
    server.extend('post', 'verify-password-code', (req, res) => {
        res.send('');
    });
    server.extend('post', 'verify-token-code', (req, res) => {
        res.send('');
    });*/
}
export default auth